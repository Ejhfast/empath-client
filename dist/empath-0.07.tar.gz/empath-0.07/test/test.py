from context import Empath

empath = Empath()
